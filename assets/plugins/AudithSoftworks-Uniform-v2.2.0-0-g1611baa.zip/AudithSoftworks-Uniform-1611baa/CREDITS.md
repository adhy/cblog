# Contributors

Much thanks to Thomas Reynolds and Buck Wilson for their help and advice on this.

Disabling text selection is made possible by Mathias Bynens <http://mathiasbynens.be/> and his noSelect plugin, <https://github.com/mathiasbynens/jquery-noselect>, which is embedded.

Tyler Akins (@fidien) has also rewritten chunks of the plugin, helped close many issues, and ensured version 2 got out the door.
